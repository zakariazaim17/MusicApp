# Mussy
An application for music enthusiasts to share music videos. 

#Includes

1.upload media *
2.browsing, searching and viewing media *
3.commenting/liking media
4.editing media
5.client statistics
6.implemented using React *
7.applying UI guidelines *
8.responsive frontend *
9.user feedback (incl. testing)
10.user registration and authentication *
11.use of the introduced toolchain *

#Used Technology

-backend provided by http://media.mw.metropolia.fi/wbma/docs/
-React native with expo /Native Base Project


group members (Amanuel, Zakaria and Ambe)
