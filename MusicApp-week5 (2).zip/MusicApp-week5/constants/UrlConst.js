const apiUrl = 'http://media.mw.metropolia.fi/wbma/';
const mediaURL = 'http://media.mw.metropolia.fi/wbma/uploads/';

export {apiUrl, mediaURL};